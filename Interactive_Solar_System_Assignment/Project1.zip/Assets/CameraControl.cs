using UnityEngine;
using TMPro; // ��������� TextMeshPro

public class CameraControl : MonoBehaviour
{
    private Transform target;
    public Vector3 originalPos = new Vector3(0, 10, -20);

    void Start() { transform.position = originalPos; }

    public void SetTarget(Transform newTarget, string fact)
    {
        target = newTarget;
        Debug.Log(fact); // �ڿ���̨��ʾС֪ʶ
    }

    void Update()
    {
        if (target != null)
        {
            // ƽ������Ŀ��
            Vector3 desiredPos = target.position + new Vector3(0, 2, -5);
            transform.position = Vector3.Lerp(transform.position, desiredPos, Time.deltaTime * 5f);
            transform.LookAt(target);
        }
    }

    // �� UI ��ť���õķ�������������ͼ
    public void ResetView()
    {
        target = null;
        transform.position = originalPos;
        transform.rotation = Quaternion.Euler(20, 0, 0); // ��ʼ�Ƕ�
    }
}